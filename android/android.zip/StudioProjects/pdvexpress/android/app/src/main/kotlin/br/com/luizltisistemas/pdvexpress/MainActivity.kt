package br.com.luizltisistemas.pdvexpress

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
